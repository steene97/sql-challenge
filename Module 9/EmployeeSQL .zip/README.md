# sql-challenge - Employee Database

1. Data Engineering

2. Data Analysis

# Data Engineering
![Fig1](EmployeeSQL/ERD.png)

# Data Analysis
Data analysis performed in files:

1. analysis_queries.sql
2. table_schema.sql

# Bonus Analysis


![Fig2](EmployeeSQL/img/Fig-1.JPG)

![Fig3](EmployeeSQL/img/Fig-2.JPG)
